/**
 */
package dsl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>World Model</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dsl.DslPackage#getWorldModel()
 * @model
 * @generated
 */
public interface WorldModel extends EObject {
} // WorldModel
