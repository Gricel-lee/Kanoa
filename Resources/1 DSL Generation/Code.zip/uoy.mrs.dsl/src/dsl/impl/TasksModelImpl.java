/**
 */
package dsl.impl;

import dsl.DslPackage;
import dsl.TasksModel;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tasks Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TasksModelImpl extends MinimalEObjectImpl.Container implements TasksModel {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TasksModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DslPackage.Literals.TASKS_MODEL;
	}

} //TasksModelImpl
