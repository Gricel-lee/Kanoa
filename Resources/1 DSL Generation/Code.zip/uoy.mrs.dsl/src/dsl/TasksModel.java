/**
 */
package dsl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tasks Model</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dsl.DslPackage#getTasksModel()
 * @model
 * @generated
 */
public interface TasksModel extends EObject {
} // TasksModel
